//
//  ImageItem.swift
//  xray
//
//  Created by Lalo Castilla on 4/9/16.
//  Copyright © 2016 EquipoDispMoviles. All rights reserved.
//

import Foundation

struct ImageItem
{
    let name: String
}